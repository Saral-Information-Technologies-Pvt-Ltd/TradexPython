valid_exchanges = {"NseCm", "NseFO", "Bse", "BseFO", "NseCD", "MCX", "Ncdex", "BseCD", "NseCO", "OFS", "BseCO"}
valid_sides = {"Buy", "Sell"}
valid_products = {"Normal", "Intraday", "CNC", "MTF"}
valid_books = {"RL", "SL", "PO", "CA2"}
valid_validity = {"Day", "IOC", "GTD", "GTC", "EOD", "EOSES"}